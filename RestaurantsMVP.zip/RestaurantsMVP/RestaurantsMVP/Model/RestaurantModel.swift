//
//  RestaurantModel.swift
//  RestaurantsMVP
//
//  Created by Amol Tamboli on 09/10/20.
//  Copyright © 2020 Amol Tamboli. All rights reserved.
//

import Foundation

class RestaurantModel {
    var id                   : String?
    var name                 : String?
    var url                  : String?
    var average_cost_for_two : Int?
    var cuisines             : String?
    var user_rating          : UserRating?

    
    // MARK: Instance Method
    func loadFromDictionary(_ dict: [String: AnyObject]) {
       
        if let data = dict["id"] as? String {
            self.id = data
        }
        
        
        if let name = dict["name"] as? String{
        self.name = name
        }
        
       if let url = dict["thumb"] as? String  {
         self.url = url
       }
        if let cuisines = dict["cuisines"] as? String  {
          self.cuisines = cuisines
        }
        
        if let averagecost = dict["average_cost_for_two"] as? Int  {
          self.average_cost_for_two = averagecost
        }
         
        if let user_rating = dict["user_rating"] as? [String: AnyObject]  {
          self.user_rating = UserRating.build(user_rating)
        }

    }
  
    // MARK: Class Method
    class func build(_ dict: [String: AnyObject]) -> RestaurantModel {
        let contact = RestaurantModel()
        contact.loadFromDictionary(dict)
        return contact
    }
}

class UserRating {
    var aggregate_rating  : String?
    var rating_text       : String?
    var rating_color      : String?
    
    // MARK: Instance Method
    func loadFromDictionary(_ dict: [String: AnyObject]) {
        if let aggregate_rating = dict["aggregate_rating"] as? String {
            self.aggregate_rating = aggregate_rating
        }
        if let rating_text = dict["rating_text"] as? String {
            self.rating_text = rating_text
        }
        if let rating_color = dict["rating_color"] as? String {
            self.rating_color = rating_color
        }
    }
    
    // MARK: Class Method
    
    class func build(_ dict: [String: AnyObject]) -> UserRating {
        let userRating = UserRating()
        userRating.loadFromDictionary(dict)
        return userRating
    }
 
}

