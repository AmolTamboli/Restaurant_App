//
// APICallManager.swift
// RestaurantsMVP
//
//  Created by Amol Tamboli on 09/10/20.
//  Copyright © 2020 Amol Tamboli. All rights reserved.
//

import Alamofire
import SwiftyJSON
import Foundation

let API_BASE_URL = "http://demo7903354.mockable.io"

class APICallManager {
    static let instance = APICallManager()
    
    enum RequestMethod {
        case get
        case post
    }
    
    enum Endpoint: String {
        case Restarants = "/restaurants"
    }
    
    // MARK: People API
    func callAPIGetRestaurant(onSuccess successCallback: ((_ restaurant: [RestaurantModel]) -> Void)?,
                          onFailure failureCallback: ((_ errorMessage: String) -> Void)?) {
        
        // Build URL
        let url = API_BASE_URL + Endpoint.Restarants.rawValue
        
        // call API
        self.createRequest(
            url, method: .get, headers: nil, parameters: nil,
            onSuccess: {(responseObject: JSON) -> Void in
                // Create dictionary
                var data = [RestaurantModel]()
                
                for (index,subJson):(String, JSON) in responseObject {
                    // Do something you want
                    //print(subJson)
                    for (index, intersubjson):(String, JSON) in subJson
                    {
                       
                        let lcDict: [String: AnyObject] = intersubjson["restaurant"].dictionaryObject as! [String : AnyObject]
                      
                    let single = RestaurantModel.build(lcDict)
                        data.append(single)
                    }
                   
                }
                
               successCallback?(data)
            
            },
            onFailure: {(errorMessage: String) -> Void in
                failureCallback?(errorMessage)
            }
        )
    }
    
    // MARK: Request Handler
    // Create request
    func createRequest(
        _ url: String,
        method: HTTPMethod,
        headers: [String: String]?,
        parameters: AnyObject?,
        onSuccess successCallback: ((JSON) -> Void)?,
        onFailure failureCallback: ((String) -> Void)?
        ) {
        
        Alamofire.request(url, method: method).validate().responseJSON { response in
            switch response.result {
            case .success(let value):
                let json = JSON(value)
                successCallback?(json)
            case .failure(let error):
                if let callback = failureCallback {
                    // Return
                    callback(error.localizedDescription)
                }
            }
        }
    }
}
