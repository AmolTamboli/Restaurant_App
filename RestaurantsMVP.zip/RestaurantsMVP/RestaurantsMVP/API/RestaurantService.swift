//
//  RestaurantService.swift
//  RestaurantsMVP
//
//  Created by Amol Tamboli on 09/10/20.
//  Copyright © 2020 Amol Tamboli. All rights reserved.
//

import Foundation

class RestaurantService {
    public func callAPIGetRestaurant(onSuccess successCallback: ((_ restaurant: [RestaurantModel]) -> Void)?,
                                 onFailure failureCallback: ((_ errorMessage: String) -> Void)?) {
        APICallManager.instance.callAPIGetRestaurant(
            onSuccess: { (restuarant) in
                successCallback?(restuarant)
            },
            onFailure: { (errorMessage) in
                failureCallback?(errorMessage)
            }
        )
    }
}
