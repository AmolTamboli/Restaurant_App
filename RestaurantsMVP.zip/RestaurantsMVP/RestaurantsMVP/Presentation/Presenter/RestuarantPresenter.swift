//
// RestuarantPresenter.swift
// RestaurantsMVP
//
//  Created by Amol Tamboli on 09/10/20.
//  Copyright © 2020 Amol Tamboli. All rights reserved.
//

import Foundation

struct RestaurantViewData{
    let name                 : String
    let url                  : String
    let cuisines             : String
    let average_cost_for_two : String
    let user_rating          : UserRating
    
    
}

protocol RestaurantView: NSObjectProtocol {
    func startLoading()
    func finishLoading()
    func setRestuarant(restaurant: [RestaurantViewData])
    func setEmptyRestarant()
}

class RestuarantPresenter {
    private let restaurantService:RestaurantService
    weak private var restaurantView : RestaurantView?
    
    init(restaurantService:RestaurantService) {
        self.restaurantService = restaurantService
    }
    
    func attachView(view:RestaurantView) {
        restaurantView = view
    }
    
    func detachView() {
        restaurantView = nil
    }
    
    func getRestaurant() {
        self.restaurantView?.startLoading()
        restaurantService.callAPIGetRestaurant(
            onSuccess: { (restaurant) in
                self.restaurantView?.finishLoading()
                if (restaurant.count == 0){
                    self.restaurantView?.setEmptyRestarant()
                } else {
                    let mappedUsers = restaurant.map {
                        return RestaurantViewData(name: "\($0.name!)", url: "\($0.url!)", cuisines: "\($0.cuisines!)", average_cost_for_two: "\($0.average_cost_for_two!)", user_rating: $0.user_rating!)
                    }
                    self.restaurantView?.setRestuarant(restaurant: mappedUsers)
                }
            },
            onFailure: { (errorMessage) in
                self.restaurantView?.finishLoading()
            }
        )
    }
}
