//
// RestaurantVC.swift
//  RestaurantsMVP
//
//  Created by Amol Tamboli on 09/10/20.
//  Copyright © 2020 Amol Tamboli. All rights reserved.
//

import UIKit
import Alamofire

class RestaurantTableViewCell: UITableViewCell {
    
    @IBOutlet weak var bgView           : UIView!
    @IBOutlet weak var m_cBekeryName    : UILabel!
    @IBOutlet weak var m_cCostlbl       : UILabel!
    @IBOutlet weak var m_cRatinglbl     : UILabel!
    @IBOutlet weak var m_cUrl           : UIImageView!
    @IBOutlet weak var Name             : UILabel!
}

class RestaurantVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
    let presenter = RestuarantPresenter(restaurantService: RestaurantService())
    var restaurantToDisplay = [RestaurantViewData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView?.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        
        activityIndicator?.hidesWhenStopped = true
        
        presenter.attachView(view: self)
        presenter.getRestaurant()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension RestaurantVC: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurantToDisplay.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let lcRestaurantTableViewCell = tableView.dequeueReusableCell(withIdentifier: "RestaurantTableViewCell", for: indexPath) as! RestaurantTableViewCell
        
        let restuarntViewData = restaurantToDisplay[indexPath.row]        

        lcRestaurantTableViewCell.Name.text = restuarntViewData.name
        lcRestaurantTableViewCell.m_cRatinglbl.text = restuarntViewData.user_rating.aggregate_rating
        lcRestaurantTableViewCell.m_cCostlbl.text = "average_cost_for_two ₹ \(restuarntViewData.average_cost_for_two)"
        lcRestaurantTableViewCell.m_cBekeryName.text = restuarntViewData.cuisines
        // Use Alamofire to download the image
        Alamofire.request(restuarntViewData.url).responseData { (response) in
            if response.error == nil {
                print(response.result)
                
                // Show the downloaded image:
                if let data = response.data {
                    lcRestaurantTableViewCell.m_cUrl.image = UIImage(data: data)
                }
            }
        }
        
        
        
        
        return lcRestaurantTableViewCell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 290
    }
    
}

extension RestaurantVC: RestaurantView {
    func startLoading() {
        // Show your loader
        activityIndicator?.startAnimating()
    }
    
    func finishLoading() {
        // Dismiss your loader
        activityIndicator?.stopAnimating()
    }
    
    func setRestuarant(restaurant: [RestaurantViewData]) {
        
        restaurantToDisplay = restaurant
        tableView?.isHidden = false
        tableView?.reloadData()
    }
    
    func setEmptyRestarant() {
        tableView?.isHidden = true
    }
}
